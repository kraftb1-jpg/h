import { Router, type IRouter } from "express";
import { eq, ilike, and, sql } from "drizzle-orm";
import { db, gamesTable } from "@workspace/db";
import {
  ListGamesQueryParams,
  CreateGameBody,
  GetGameParams,
  GetGameResponse,
  UpdateGameParams,
  UpdateGameBody,
  UpdateGameResponse,
  DeleteGameParams,
  ListGamesResponse,
  GetFeaturedGamesResponse,
  GetGameStatsResponse,
  ListGenresResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/games/featured", async (_req, res): Promise<void> => {
  const games = await db
    .select()
    .from(gamesTable)
    .where(eq(gamesTable.isFeatured, true))
    .orderBy(gamesTable.playCount);
  res.json(GetFeaturedGamesResponse.parse(games.map(g => ({ ...g, createdAt: g.createdAt.toISOString() }))));
});

router.get("/games/stats", async (_req, res): Promise<void> => {
  const [totals] = await db
    .select({
      totalGames: sql<number>`count(*)::int`,
      totalPlays: sql<number>`sum(${gamesTable.playCount})::int`,
      featuredCount: sql<number>`count(*) filter (where ${gamesTable.isFeatured})::int`,
    })
    .from(gamesTable);

  const genreResult = await db
    .selectDistinct({ genre: gamesTable.genre })
    .from(gamesTable);

  res.json(
    GetGameStatsResponse.parse({
      totalGames: totals?.totalGames ?? 0,
      totalGenres: genreResult.length,
      totalPlays: totals?.totalPlays ?? 0,
      featuredCount: totals?.featuredCount ?? 0,
    })
  );
});

router.get("/games", async (req, res): Promise<void> => {
  const parsed = ListGamesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { genre, search, featured } = parsed.data;
  const conditions = [];

  if (genre) conditions.push(eq(gamesTable.genre, genre));
  if (search) conditions.push(ilike(gamesTable.title, `%${search}%`));
  if (featured !== undefined) conditions.push(eq(gamesTable.isFeatured, featured));

  const games = await db
    .select()
    .from(gamesTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(gamesTable.createdAt);

  res.json(ListGamesResponse.parse(games.map(g => ({ ...g, createdAt: g.createdAt.toISOString() }))));
});

router.post("/games", async (req, res): Promise<void> => {
  const parsed = CreateGameBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [game] = await db.insert(gamesTable).values(parsed.data).returning();
  res.status(201).json(GetGameResponse.parse({ ...game, createdAt: game.createdAt.toISOString() }));
});

router.get("/games/:id", async (req, res): Promise<void> => {
  const params = GetGameParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [game] = await db
    .select()
    .from(gamesTable)
    .where(eq(gamesTable.id, params.data.id));

  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  res.json(GetGameResponse.parse({ ...game, createdAt: game.createdAt.toISOString() }));
});

router.patch("/games/:id", async (req, res): Promise<void> => {
  const params = UpdateGameParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateGameBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [game] = await db
    .update(gamesTable)
    .set(parsed.data)
    .where(eq(gamesTable.id, params.data.id))
    .returning();

  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  res.json(UpdateGameResponse.parse({ ...game, createdAt: game.createdAt.toISOString() }));
});

router.delete("/games/:id", async (req, res): Promise<void> => {
  const params = DeleteGameParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [game] = await db
    .delete(gamesTable)
    .where(eq(gamesTable.id, params.data.id))
    .returning();

  if (!game) {
    res.status(404).json({ error: "Game not found" });
    return;
  }

  res.sendStatus(204);
});

router.get("/genres", async (_req, res): Promise<void> => {
  const result = await db
    .select({
      genre: gamesTable.genre,
      count: sql<number>`count(*)::int`,
    })
    .from(gamesTable)
    .groupBy(gamesTable.genre)
    .orderBy(gamesTable.genre);

  res.json(ListGenresResponse.parse(result.map(r => ({ name: r.genre, count: r.count }))));
});

export default router;

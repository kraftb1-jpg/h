import { Layout } from "@/components/layout";
import { GameCard } from "@/components/game-card";
import { useGetFeaturedGames, useGetGameStats, useListGenres, useListGames } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Activity, Gamepad2, Zap, Trophy } from "lucide-react";

function StatCard({ icon: Icon, label, value, colorClass }: { icon: any, label: string, value: string | number, colorClass: string }) {
  return (
    <div className={`p-4 rounded-lg border bg-card/50 backdrop-blur-sm flex items-center gap-4 ${colorClass}`}>
      <div className="p-3 rounded-md bg-background/80 border border-current">
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <p className="font-mono text-xs uppercase tracking-wider opacity-80">{label}</p>
        <p className="font-display text-2xl font-bold">{value}</p>
      </div>
    </div>
  );
}

export default function Home() {
  const { data: featuredGames, isLoading: isLoadingFeatured } = useGetFeaturedGames();
  const { data: stats, isLoading: isLoadingStats } = useGetGameStats();
  const { data: genres, isLoading: isLoadingGenres } = useListGenres();
  const { data: recentGames, isLoading: isLoadingRecent } = useListGames({ search: "", genre: "" }, { query: { queryKey: ["recent_games"] }}); // we just use generic list for "recent"

  return (
    <Layout>
      {/* Hero Section */}
      <section className="mb-16 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-secondary/10 blur-3xl -z-10" />
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto space-y-6 py-12">
          <Badge className="bg-primary/10 text-primary border-primary/30 font-mono neon-text uppercase py-1 px-3">
            System Online
          </Badge>
          <h1 className="text-5xl md:text-7xl font-black font-display tracking-tight leading-tight">
            ENTER THE <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary neon-text">NEXUS</span>
          </h1>
          <p className="text-lg text-muted-foreground font-sans max-w-xl">
            Instant action. No downloads. Browse hundreds of hand-picked browser games and jump straight into the action.
          </p>
          <div className="flex items-center gap-4 pt-4">
            <Link href="/games">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-display uppercase tracking-widest shadow-[0_0_20px_rgba(0,240,255,0.4)]">
                Browse Library
              </Button>
            </Link>
            <Link href="/games?featured=true">
              <Button size="lg" variant="outline" className="border-secondary/50 text-secondary hover:bg-secondary/10 font-display uppercase tracking-widest">
                Top Rated
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Stats Dashboard */}
      <section className="mb-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {isLoadingStats ? (
            Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-24 w-full bg-card/50" />)
          ) : stats ? (
            <>
              <StatCard icon={Gamepad2} label="Total Games" value={stats.totalGames} colorClass="border-primary/30 text-primary shadow-[inset_0_0_20px_rgba(0,240,255,0.05)]" />
              <StatCard icon={Activity} label="Total Plays" value={(stats.totalPlays / 1000).toFixed(1) + 'K'} colorClass="border-secondary/30 text-secondary shadow-[inset_0_0_20px_rgba(255,0,255,0.05)]" />
              <StatCard icon={Zap} label="Genres" value={stats.totalGenres} colorClass="border-yellow-500/30 text-yellow-500 shadow-[inset_0_0_20px_rgba(234,179,8,0.05)]" />
              <StatCard icon={Trophy} label="Featured" value={stats.featuredCount} colorClass="border-accent/30 text-accent shadow-[inset_0_0_20px_rgba(176,38,255,0.05)]" />
            </>
          ) : null}
        </div>
      </section>

      {/* Featured Games */}
      <section className="mb-16">
        <div className="flex items-center justify-between mb-6 border-b border-border/40 pb-2">
          <h2 className="text-2xl font-display font-bold flex items-center gap-2">
            <Trophy className="text-secondary w-6 h-6" /> 
            <span className="neon-text-secondary">Featured Titles</span>
          </h2>
          <Link href="/games?featured=true">
            <Button variant="ghost" size="sm" className="font-mono text-xs text-muted-foreground hover:text-primary">
              View All <ArrowRight className="w-3 h-3 ml-1" />
            </Button>
          </Link>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 auto-rows-[minmax(200px,auto)]">
          {isLoadingFeatured ? (
            Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-64 w-full bg-card/50" />)
          ) : featuredGames?.length ? (
            featuredGames.slice(0, 5).map((game, i) => (
              <GameCard key={game.id} game={game} featured={i === 0} />
            ))
          ) : (
            <div className="col-span-full py-12 text-center text-muted-foreground font-mono">
              No featured games found.
            </div>
          )}
        </div>
      </section>

      {/* Genres Quick Filters */}
      <section className="mb-16">
        <h2 className="text-xl font-display font-bold mb-6 text-muted-foreground">Select Protocol</h2>
        <div className="flex flex-wrap gap-3">
          {isLoadingGenres ? (
            Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-10 w-24 rounded-full bg-card/50" />)
          ) : genres?.length ? (
            genres.map((genre) => (
              <Link key={genre.name} href={`/games?genre=${encodeURIComponent(genre.name)}`}>
                <Button variant="outline" className="rounded-full border-primary/20 hover:border-primary/60 hover:bg-primary/10 hover:text-primary font-mono transition-all">
                  {genre.name} <span className="ml-2 text-xs opacity-50">[{genre.count}]</span>
                </Button>
              </Link>
            ))
          ) : null}
        </div>
      </section>

    </Layout>
  );
}

// Needs Badge import
import { Badge } from "@/components/ui/badge";

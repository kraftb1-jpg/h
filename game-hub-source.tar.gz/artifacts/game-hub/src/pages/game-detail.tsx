import { Layout } from "@/components/layout";
import { useGetGame, useListGames } from "@workspace/api-client-react";
import { useRoute } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { GameCard } from "@/components/game-card";
import { Calendar, Play, Star, Trophy, Users, AlertCircle, Maximize2 } from "lucide-react";
import { format } from "date-fns";

export default function GameDetail() {
  const [, params] = useRoute("/games/:id");
  const gameId = params?.id ? parseInt(params.id, 10) : 0;

  const { data: game, isLoading, isError } = useGetGame(gameId, {
    query: {
      enabled: !!gameId,
      queryKey: ["game", gameId]
    }
  });

  // Fetch similar games based on genre once we have the game data
  const { data: similarGames, isLoading: isLoadingSimilar } = useListGames(
    { genre: game?.genre },
    { query: { enabled: !!game?.genre, queryKey: ["games", "similar", game?.genre] }}
  );

  if (isError || (!isLoading && !game)) {
    return (
      <Layout>
        <div className="min-h-[50vh] flex flex-col items-center justify-center text-center">
          <AlertCircle className="w-16 h-16 text-destructive mb-4" />
          <h1 className="text-3xl font-display text-destructive">SYSTEM_ERROR</h1>
          <p className="font-mono text-muted-foreground mt-2">Title not found in database.</p>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {isLoading ? (
        <div className="space-y-8">
          <Skeleton className="w-full aspect-[21/9] md:aspect-[3/1] rounded-xl bg-card/50" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <Skeleton className="h-12 w-3/4 bg-card/50" />
              <Skeleton className="h-24 w-full bg-card/50" />
            </div>
            <div className="space-y-4">
              <Skeleton className="h-48 w-full bg-card/50" />
            </div>
          </div>
        </div>
      ) : game ? (
        <div className="space-y-12">
          
          {/* Header/Hero Area */}
          <div className="relative rounded-xl overflow-hidden bg-muted aspect-[21/9] md:aspect-[3/1] border border-border/50 shadow-2xl">
            {game.thumbnailUrl ? (
              <img 
                src={game.thumbnailUrl} 
                alt={game.title} 
                className="w-full h-full object-cover opacity-40 blur-[2px]"
              />
            ) : (
              <div className="w-full h-full bg-background" />
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
            
            <div className="absolute bottom-0 left-0 p-6 md:p-10 w-full flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div className="space-y-4 max-w-3xl">
                <div className="flex flex-wrap items-center gap-3">
                  {game.isFeatured && (
                    <Badge className="bg-secondary/20 text-secondary border-secondary/50 neon-text-secondary">
                      <Trophy className="w-3 h-3 mr-1" /> Featured
                    </Badge>
                  )}
                  <Badge variant="outline" className="border-primary/50 text-primary bg-background/50 backdrop-blur-sm">
                    {game.genre}
                  </Badge>
                </div>
                
                <h1 className="text-4xl md:text-6xl font-display font-black text-foreground drop-shadow-lg">
                  {game.title}
                </h1>
              </div>

              {game.playUrl && (
                <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-display text-lg px-8 py-6 h-auto shadow-[0_0_30px_rgba(0,240,255,0.4)] neon-border shrink-0" asChild>
                  <a href="#play-section">
                    <Play className="w-6 h-6 mr-2 fill-current" />
                    INITIALIZE
                  </a>
                </Button>
              )}
            </div>
          </div>

          {/* Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <section>
                <h2 className="text-xl font-display text-muted-foreground mb-4 border-b border-border/40 pb-2">Description</h2>
                <p className="text-lg leading-relaxed font-sans opacity-90 whitespace-pre-wrap">
                  {game.description}
                </p>
              </section>

              {/* Game Frame Section */}
              {game.playUrl && (
                <section id="play-section" className="scroll-mt-24">
                  <div className="flex items-center justify-between mb-4 border-b border-border/40 pb-2">
                    <h2 className="text-xl font-display text-primary neon-text flex items-center gap-2">
                      <Play className="w-5 h-5" /> ACTIVE_INSTANCE
                    </h2>
                    <Button variant="ghost" size="sm" className="font-mono text-xs text-muted-foreground">
                      <Maximize2 className="w-4 h-4 mr-1" /> Fullscreen
                    </Button>
                  </div>
                  
                  <div className="rounded-xl overflow-hidden border-2 border-primary/30 shadow-[0_0_40px_rgba(0,240,255,0.1)] bg-black aspect-video relative group">
                    <iframe 
                      src={game.playUrl}
                      className="w-full h-full absolute inset-0"
                      title={game.title}
                      allow="autoplay; fullscreen"
                    />
                    <div className="absolute inset-0 pointer-events-none ring-1 ring-inset ring-white/10 rounded-xl" />
                  </div>
                </section>
              )}
            </div>

            {/* Sidebar Stats */}
            <div className="space-y-6">
              <div className="p-6 rounded-xl border border-border/50 bg-card/30 backdrop-blur-sm space-y-6">
                <h3 className="font-display text-lg border-b border-border/40 pb-2">Telemetry</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
                      <Users className="w-4 h-4" /> Players
                    </div>
                    <div className="font-display font-bold text-lg">
                      {game.playCount.toLocaleString()}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
                      <Star className="w-4 h-4 text-yellow-500" /> Rating
                    </div>
                    <div className="font-display font-bold text-lg text-yellow-500">
                      {game.rating ? game.rating.toFixed(1) + " / 5.0" : "N/A"}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-muted-foreground font-mono text-sm">
                      <Calendar className="w-4 h-4" /> Added
                    </div>
                    <div className="font-mono text-sm">
                      {format(new Date(game.createdAt), "MMM d, yyyy")}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Similar Games */}
          <section className="pt-12 border-t border-border/40">
            <h2 className="text-2xl font-display font-bold mb-6 flex items-center gap-2">
              Similar Protocols <span className="text-muted-foreground text-sm font-mono font-normal">[{game.genre}]</span>
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {isLoadingSimilar ? (
                Array(4).fill(0).map((_, i) => <Skeleton key={i} className="h-64 w-full bg-card/50" />)
              ) : similarGames ? (
                similarGames
                  .filter(g => g.id !== game.id)
                  .slice(0, 4)
                  .map(g => <GameCard key={g.id} game={g} />)
              ) : null}
            </div>
          </section>

        </div>
      ) : null}
    </Layout>
  );
}

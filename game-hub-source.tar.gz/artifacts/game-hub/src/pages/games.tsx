import { Layout } from "@/components/layout";
import { useListGames, useListGenres } from "@workspace/api-client-react";
import { GameCard } from "@/components/game-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Filter, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";

export default function Games() {
  const [location, setLocation] = useLocation();
  
  // Parse URL params for initial state
  const searchParams = new URLSearchParams(window.location.search);
  const initialGenre = searchParams.get("genre") || "";
  const initialSearch = searchParams.get("search") || "";
  const initialFeatured = searchParams.get("featured") === "true";

  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedGenre, setSelectedGenre] = useState(initialGenre);
  const [showFeaturedOnly, setShowFeaturedOnly] = useState(initialFeatured);

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (searchQuery) params.set("search", searchQuery);
    if (selectedGenre) params.set("genre", selectedGenre);
    if (showFeaturedOnly) params.set("featured", "true");
    
    const newSearch = params.toString();
    const newUrl = newSearch ? `/games?${newSearch}` : "/games";
    
    // Only update if it actually changed to avoid loop
    if (window.location.search !== `?${newSearch}` && (window.location.search || newSearch)) {
      setLocation(newUrl, { replace: true });
    }
  }, [searchQuery, selectedGenre, showFeaturedOnly, setLocation]);

  const { data: games, isLoading: isLoadingGames } = useListGames(
    { 
      search: searchQuery || undefined, 
      genre: selectedGenre || undefined,
      featured: showFeaturedOnly || undefined
    }, 
    { 
      query: { 
        queryKey: ["games", searchQuery, selectedGenre, showFeaturedOnly] 
      } 
    }
  );

  const { data: genres, isLoading: isLoadingGenres } = useListGenres();

  return (
    <Layout>
      <div className="flex flex-col md:flex-row gap-8 items-start">
        
        {/* Sidebar Filters */}
        <aside className="w-full md:w-64 shrink-0 space-y-6 sticky top-24">
          <div>
            <h2 className="font-display text-lg mb-4 flex items-center gap-2 border-b border-border/40 pb-2">
              <Filter className="w-5 h-5 text-primary" />
              DATABASE_QUERY
            </h2>
            
            <div className="relative mb-6">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search titles..." 
                className="pl-9 bg-card/50 border-primary/20 focus-visible:ring-primary/50 font-mono text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-xs font-mono uppercase text-muted-foreground mb-3">Status</h3>
                <Button
                  variant={showFeaturedOnly ? "default" : "outline"}
                  size="sm"
                  className={`w-full justify-start font-mono text-sm ${showFeaturedOnly ? 'bg-secondary/20 text-secondary border-secondary hover:bg-secondary/30' : 'border-border hover:border-secondary/50'}`}
                  onClick={() => setShowFeaturedOnly(!showFeaturedOnly)}
                >
                  {showFeaturedOnly ? <X className="w-3 h-3 mr-2" /> : null}
                  Featured Only
                </Button>
              </div>

              <div>
                <h3 className="text-xs font-mono uppercase text-muted-foreground mb-3">Protocols (Genres)</h3>
                <div className="space-y-1 max-h-[40vh] overflow-y-auto pr-2 scrollbar-thin">
                  <Button
                    variant={selectedGenre === "" ? "default" : "ghost"}
                    size="sm"
                    className={`w-full justify-start font-mono text-sm ${selectedGenre === "" ? 'bg-primary/20 text-primary hover:bg-primary/30' : 'text-muted-foreground hover:text-foreground'}`}
                    onClick={() => setSelectedGenre("")}
                  >
                    All Genres
                  </Button>
                  
                  {isLoadingGenres ? (
                    Array(5).fill(0).map((_, i) => <Skeleton key={i} className="h-8 w-full bg-card/30 mt-1" />)
                  ) : genres?.map((genre) => (
                    <Button
                      key={genre.name}
                      variant={selectedGenre === genre.name ? "default" : "ghost"}
                      size="sm"
                      className={`w-full justify-start font-mono text-sm ${selectedGenre === genre.name ? 'bg-primary/20 text-primary hover:bg-primary/30' : 'text-muted-foreground hover:text-foreground'}`}
                      onClick={() => setSelectedGenre(genre.name)}
                    >
                      <span className="truncate">{genre.name}</span>
                      <span className="ml-auto text-xs opacity-50">{genre.count}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 w-full">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-display font-bold">
              {selectedGenre ? `${selectedGenre} Titles` : 'All Titles'}
            </h1>
            <div className="font-mono text-sm text-muted-foreground">
              {isLoadingGames ? 'Scanning...' : `Found ${games?.length || 0} matches`}
            </div>
          </div>

          {isLoadingGames ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-64 w-full bg-card/50" />)}
            </div>
          ) : games?.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {games.map(game => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          ) : (
            <div className="py-24 text-center border border-dashed border-border/50 rounded-lg bg-card/20">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted/50 mb-4">
                <Search className="w-8 h-8 text-muted-foreground/50" />
              </div>
              <h3 className="font-display text-lg mb-2">No results found</h3>
              <p className="font-mono text-sm text-muted-foreground max-w-md mx-auto">
                Adjust your query parameters to locate matching titles.
              </p>
              <Button 
                variant="outline" 
                className="mt-6 font-mono"
                onClick={() => {
                  setSearchQuery("");
                  setSelectedGenre("");
                  setShowFeaturedOnly(false);
                }}
              >
                Reset Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

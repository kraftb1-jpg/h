import { Link, useLocation } from "wouter";
import { Gamepad2, Compass, Home, Search } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-[100dvh] flex flex-col w-full relative">
      <div className="fixed inset-0 pointer-events-none z-[-1] opacity-20 bg-[url('https://grainy-gradients.vercel.app/noise.svg')]" />
      
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center neon-border group-hover:bg-primary/20 transition-all">
              <Gamepad2 className="w-6 h-6 text-primary group-hover:text-secondary transition-colors" />
            </div>
            <span className="font-display font-bold text-xl tracking-wider neon-text hidden sm:inline-block">
              NEXUS_ARCADE
            </span>
          </Link>

          <nav className="flex items-center gap-2">
            <Link href="/">
              <Button 
                variant={location === "/" ? "default" : "ghost"} 
                className={`font-mono uppercase tracking-wider ${location === "/" ? "neon-border" : "hover:text-primary"}`}
              >
                <Home className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline-block">Terminal</span>
              </Button>
            </Link>
            <Link href="/games">
              <Button 
                variant={location === "/games" ? "default" : "ghost"} 
                className={`font-mono uppercase tracking-wider ${location === "/games" ? "neon-border" : "hover:text-secondary"}`}
              >
                <Compass className="w-4 h-4 mr-2" />
                <span className="hidden sm:inline-block">Library</span>
              </Button>
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8">
        {children}
      </main>

      <footer className="border-t border-border/40 py-8 bg-background/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Gamepad2 className="w-5 h-5 text-muted-foreground" />
            <span className="font-mono text-sm text-muted-foreground">NEXUS_ARCADE SYSTEM v1.0</span>
          </div>
          <p className="font-mono text-xs text-muted-foreground/60 uppercase">
            Insert Coin to Continue
          </p>
        </div>
      </footer>
    </div>
  );
}

import { Game } from "@workspace/api-client-react/src/generated/api.schemas";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Play, Star, TrendingUp } from "lucide-react";

interface GameCardProps {
  game: Game;
  featured?: boolean;
}

export function GameCard({ game, featured = false }: GameCardProps) {
  return (
    <Link href={`/games/${game.id}`}>
      <Card className={`group cursor-pointer overflow-hidden bg-card/50 backdrop-blur-sm neon-border transition-all duration-300 hover:-translate-y-1 ${featured ? 'md:col-span-2 md:row-span-2' : ''}`}>
        <div className="relative aspect-video w-full overflow-hidden bg-muted">
          {game.thumbnailUrl ? (
            <img 
              src={game.thumbnailUrl} 
              alt={game.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-muted-foreground/10">
              <Gamepad2 className="w-12 h-12 text-muted-foreground/30" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent opacity-80" />
          
          <div className="absolute top-3 right-3 flex flex-col gap-2">
            {game.isFeatured && (
              <Badge variant="secondary" className="bg-secondary/20 text-secondary border-secondary/50 neon-text-secondary uppercase font-mono shadow-[0_0_10px_rgba(255,0,255,0.3)]">
                Featured
              </Badge>
            )}
            <Badge variant="outline" className="bg-background/80 backdrop-blur-sm border-primary/30 text-primary font-mono ml-auto">
              {game.genre}
            </Badge>
          </div>

          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-background/40 backdrop-blur-[2px]">
            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center border border-primary/50 text-primary shadow-[0_0_20px_rgba(0,240,255,0.4)]">
              <Play className="w-8 h-8 ml-1" />
            </div>
          </div>
        </div>

        <CardContent className="p-4 relative">
          <div className="flex justify-between items-start mb-2">
            <h3 className="font-display font-bold text-lg truncate pr-4 text-foreground group-hover:text-primary transition-colors">
              {game.title}
            </h3>
            {game.rating && (
              <div className="flex items-center gap-1 text-yellow-500 bg-yellow-500/10 px-2 py-0.5 rounded border border-yellow-500/20 whitespace-nowrap">
                <Star className="w-3 h-3 fill-current" />
                <span className="font-mono text-xs">{game.rating.toFixed(1)}</span>
              </div>
            )}
          </div>
          
          <p className={`text-muted-foreground font-sans text-sm line-clamp-2 ${featured ? 'md:line-clamp-3' : ''}`}>
            {game.description}
          </p>

          <div className="mt-4 flex items-center gap-4 text-xs font-mono text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Play className="w-3 h-3" />
              {game.playCount.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5">
              <TrendingUp className="w-3 h-3 text-secondary" />
              HOT
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

// Ensure Gamepad2 is available for the fallback
import { Gamepad2 } from "lucide-react";
